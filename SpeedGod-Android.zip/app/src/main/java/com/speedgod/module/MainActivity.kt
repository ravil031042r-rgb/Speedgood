package com.speedgod.module

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B1120"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(44f), dp(20f), dp(32f))
        }

        val title = TextView(this).apply {
            text = "⚡ SpeedGod"
            setTextColor(Color.parseColor("#22D3EE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            typeface = Typeface.DEFAULT_BOLD
        }

        val subtitle = TextView(this).apply {
            text = "Нативный Xposed/LSPatch спидхак (C++ ShadowHook + плавающее меню без Root)"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(0, dp(6f), 0, dp(20f))
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(16f), dp(16f), dp(16f))
            background = GradientDrawable().apply {
                cornerRadius = dp(16f).toFloat()
                setColor(Color.parseColor("#111C33"))
                setStroke(dp(1f), Color.parseColor("#1E293B"))
            }
        }

        val stepsTitle = TextView(this).apply {
            text = "Как вшить в любой APK без Root"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10f))
        }

        val stepsBody = TextView(this).apply {
            text = listOf(
                "1. Установите LSPatch (актуальный форк JingMatrix с поддержкой Android 14–16).",
                "2. Откройте LSPatch → вкладка «Управление» → «+» → выберите нужное приложение или APK-файл.",
                "3. Выберите режим «Встроенный» (Integrated / Embedded), чтобы модуль вшился прямо внутрь APK.",
                "4. Нажмите «Встроить модули» и выберите SpeedGod.",
                "5. Нажмите «Начать патч», удалите оригинал игры и установите пропатченный APK.",
                "6. При запуске игры поверх экрана сразу появится кнопка ⚡ 1x (разрешения не нужны!).",
                "",
                "Управление кнопкой:",
                "• Короткое нажатие — открыть панель скорости",
                "• Перетаскивание — переместить в любой угол",
                "• Долгое нажатие — быстрый сброс на 1x"
            ).joinToString("\n")
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setLineSpacing(dp(4f).toFloat(), 1f)
        }

        card.addView(stepsTitle)
        card.addView(stepsBody)

        root.addView(title)
        root.addView(subtitle)
        root.addView(card)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun dp(value: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        ).roundToInt()
    }
}
