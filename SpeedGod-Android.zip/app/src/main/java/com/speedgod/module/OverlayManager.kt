package com.speedgod.module

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.lang.ref.WeakReference
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Zero-permission iGameGod-style floating speed controller attached directly to Activity DecorView.
 * Pure programmatic Android Views (zero R.* resource lookups inside target apps).
 */
object OverlayManager {

    private const val ROOT_TAG = "SpeedGod_Overlay_Root_V1"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var currentActivityRef: WeakReference<Activity>? = null
    private var savedXFraction: Float = 0.03f
    private var savedYFraction: Float = 0.25f
    private var isExpanded: Boolean = false
    private var isDimmed: Boolean = false

    fun attachToActivity(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed) return
        currentActivityRef = WeakReference(activity)

        mainHandler.post {
            try {
                if (activity.isFinishing || activity.isDestroyed) return@post
                val decor = activity.window?.decorView as? ViewGroup ?: return@post

                decor.findViewWithTag<View>(ROOT_TAG)?.let { existing ->
                    decor.removeView(existing)
                }

                val overlayRoot = buildOverlayView(activity, decor)
                overlayRoot.tag = ROOT_TAG
                decor.addView(
                    overlayRoot,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                    )
                )
            } catch (_: Throwable) {
                // Never crash the host app
            }
        }
    }

    fun detachFromActivity(activity: Activity) {
        mainHandler.post {
            try {
                val decor = activity.window?.decorView as? ViewGroup ?: return@post
                decor.findViewWithTag<View>(ROOT_TAG)?.let { existing ->
                    decor.removeView(existing)
                }
            } catch (_: Throwable) {
            }
        }
    }

    private fun buildOverlayView(context: Context, decor: ViewGroup): FrameLayout {
        val root = FrameLayout(context).apply {
            isClickable = false
            isFocusable = false
            elevation = dp(context, 24f).toFloat()
        }

        val pillButton = createFloatingPill(context)
        val panelCard = createControlPanel(context, pillButton)

        val pillLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        val panelLp = FrameLayout.LayoutParams(
            dp(context, 286f),
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.CENTER
        }

        root.addView(pillButton, pillLp)
        root.addView(panelCard, panelLp)

        pillButton.visibility = if (isExpanded) View.GONE else View.VISIBLE
        panelCard.visibility = if (isExpanded) View.VISIBLE else View.GONE
        pillButton.alpha = if (isDimmed) 0.30f else 0.94f

        root.post {
            val maxW = (decor.width - pillButton.width).coerceAtLeast(1)
            val maxH = (decor.height - pillButton.height).coerceAtLeast(1)
            pillButton.x = (savedXFraction * maxW).coerceIn(0f, maxW.toFloat())
            pillButton.y = (savedYFraction * maxH).coerceIn(dp(context, 28f).toFloat(), maxH.toFloat())
        }

        setupPillTouchBehavior(context, decor, pillButton, panelCard)

        return root
    }

    private fun createFloatingPill(context: Context): TextView {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 22f).toFloat()
            setColor(Color.parseColor("#E60F172A"))
            setStroke(dp(context, 1.5f), Color.parseColor("#22D3EE"))
        }

        return TextView(context).apply {
            text = formatPillText(NativeSpeedBridge.currentSpeed)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(context, 13f), dp(context, 8f), dp(context, 13f), dp(context, 8f))
            elevation = dp(context, 12f).toFloat()
        }
    }

    private fun createControlPanel(context: Context, pillButton: TextView): LinearLayout {
        val cardBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 18f).toFloat()
            setColor(Color.parseColor("#F00F172A"))
            setStroke(dp(context, 1.5f), Color.parseColor("#334155"))
        }

        val panel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = cardBg
            setPadding(dp(context, 14f), dp(context, 12f), dp(context, 14f), dp(context, 12f))
            isClickable = true
            elevation = dp(context, 20f).toFloat()
        }

        // --- Header Row ---
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val titleText = TextView(context).apply {
            text = "⚡ SpeedGod"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
        }

        val isNative = NativeSpeedBridge.isNativeLoaded
        val statusBadge = TextView(context).apply {
            text = if (isNative) "● ${NativeSpeedBridge.statusText}" else "● Java Fallback"
            setTextColor(if (isNative) Color.parseColor("#34D399") else Color.parseColor("#FBBF24"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
        }

        titleCol.addView(titleText)
        titleCol.addView(statusBadge)

        val closeBtn = createChipButton(context, "✕", "#1E293B", "#CBD5E1") {
            isExpanded = false
            panel.visibility = View.GONE
            pillButton.visibility = View.VISIBLE
        }

        header.addView(titleCol)
        header.addView(closeBtn)
        panel.addView(header)

        // --- Speed Display + Stepper Row ---
        val speedDisplay = TextView(context).apply {
            text = formatSpeedBig(NativeSpeedBridge.currentSpeed)
            setTextColor(Color.parseColor("#22D3EE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val slider = SeekBar(context).apply {
            max = 100
            progress = speedToSliderProgress(NativeSpeedBridge.currentSpeed)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(context, 4f)
                bottomMargin = dp(context, 8f)
            }
        }

        fun updateSpeedUi(newSpeed: Double, updateSlider: Boolean = true) {
            val rounded = if (newSpeed == 0.0) 0.0 else (newSpeed * 100.0).roundToInt() / 100.0
            NativeSpeedBridge.setSpeed(rounded)
            speedDisplay.text = formatSpeedBig(rounded)
            pillButton.text = formatPillText(rounded)
            if (updateSlider) {
                slider.progress = speedToSliderProgress(rounded)
            }
        }

        val stepperRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(context, 8f)
            }
        }

        val minusBtn = createChipButton(context, "−0.5", "#1E293B", "#F8FAFC") {
            val next = (NativeSpeedBridge.currentSpeed - 0.5).coerceAtLeast(0.0)
            updateSpeedUi(next)
        }
        val plusBtn = createChipButton(context, "+0.5", "#1E293B", "#F8FAFC") {
            val next = (NativeSpeedBridge.currentSpeed + 0.5).coerceAtMost(50.0)
            updateSpeedUi(next)
        }

        stepperRow.addView(minusBtn)
        stepperRow.addView(speedDisplay)
        stepperRow.addView(plusBtn)
        panel.addView(stepperRow)

        // --- Logarithmic SeekBar (0.1x .. 25.0x) ---
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val spd = sliderProgressToSpeed(progress)
                    updateSpeedUi(spd, updateSlider = false)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        panel.addView(slider)

        // --- Preset Rows ---
        val presetsRow1 = listOf(
            "⏸ 0x" to 0.0,
            "0.25x" to 0.25,
            "0.5x" to 0.5,
            "1x" to 1.0
        )
        val presetsRow2 = listOf(
            "2x" to 2.0,
            "3x" to 3.0,
            "5x" to 5.0,
            "10x" to 10.0,
            "20x" to 20.0
        )

        panel.addView(createPresetRow(context, presetsRow1) { spd -> updateSpeedUi(spd) })
        panel.addView(createPresetRow(context, presetsRow2) { spd -> updateSpeedUi(spd) })

        // --- Advanced Toggles Row ---
        val togglesRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(context, 8f)
            }
        }

        lateinit var rtBtn: TextView
        rtBtn = createToggleChip(context, "RT: ${if (NativeSpeedBridge.hookRealtime) "ON" else "OFF"}", NativeSpeedBridge.hookRealtime) {
            val next = !NativeSpeedBridge.hookRealtime
            NativeSpeedBridge.setHookRealtime(next)
            rtBtn.text = "RT: ${if (next) "ON" else "OFF"}"
            styleToggleChip(context, rtBtn, next)
        }

        lateinit var sleepBtn: TextView
        sleepBtn = createToggleChip(context, "Sleep: ${if (NativeSpeedBridge.hookSleep) "ON" else "OFF"}", NativeSpeedBridge.hookSleep) {
            val next = !NativeSpeedBridge.hookSleep
            NativeSpeedBridge.setHookSleep(next)
            sleepBtn.text = "Sleep: ${if (next) "ON" else "OFF"}"
            styleToggleChip(context, sleepBtn, next)
        }

        lateinit var dimBtn: TextView
        dimBtn = createToggleChip(context, if (isDimmed) "Прозр: ON" else "Прозр: OFF", isDimmed) {
            isDimmed = !isDimmed
            pillButton.alpha = if (isDimmed) 0.30f else 0.94f
            dimBtn.text = if (isDimmed) "Прозр: ON" else "Прозр: OFF"
            styleToggleChip(context, dimBtn, isDimmed)
        }

        togglesRow.addView(rtBtn, weightedMarginParams(context))
        togglesRow.addView(sleepBtn, weightedMarginParams(context))
        togglesRow.addView(dimBtn, weightedMarginParams(context))
        panel.addView(togglesRow)

        return panel
    }

    private fun createPresetRow(
        context: Context,
        items: List<Pair<String, Double>>,
        onSelect: (Double) -> Unit
    ): LinearLayout {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(context, 5f)
            }
        }

        for ((label, value) in items) {
            val bgColor = if (value == 1.0) "#0E7490" else "#1E293B"
            val btn = createChipButton(context, label, bgColor, "#F8FAFC") {
                onSelect(value)
            }
            row.addView(btn, weightedMarginParams(context))
        }
        return row
    }

    private fun createChipButton(
        context: Context,
        label: String,
        bgHex: String,
        textHex: String,
        onClick: () -> Unit
    ): TextView {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 10f).toFloat()
            setColor(Color.parseColor(bgHex))
        }
        return TextView(context).apply {
            text = label
            setTextColor(Color.parseColor(textHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bg
            setPadding(dp(context, 8f), dp(context, 7f), dp(context, 8f), dp(context, 7f))
            setOnClickListener { onClick() }
        }
    }

    private fun createToggleChip(
        context: Context,
        label: String,
        active: Boolean,
        onClick: () -> Unit
    ): TextView {
        return TextView(context).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(context, 6f), dp(context, 6f), dp(context, 6f), dp(context, 6f))
            styleToggleChip(context, this, active)
            setOnClickListener { onClick() }
        }
    }

    private fun styleToggleChip(context: Context, tv: TextView, active: Boolean) {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 8f).toFloat()
            setColor(if (active) Color.parseColor("#164E63") else Color.parseColor("#1E293B"))
            setStroke(
                dp(context, 1f),
                if (active) Color.parseColor("#22D3EE") else Color.parseColor("#334155")
            )
        }
        tv.background = bg
        tv.setTextColor(if (active) Color.parseColor("#67E8F9") else Color.parseColor("#94A3B8"))
    }

    private fun setupPillTouchBehavior(
        context: Context,
        decor: ViewGroup,
        pill: TextView,
        panel: View
    ) {
        val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0f
        var startY = 0f
        var dragging = false
        var downTime = 0L

        pill.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = v.x
                    startY = v.y
                    dragging = false
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        dragging = true
                    }
                    if (dragging) {
                        val maxW = (decor.width - v.width).coerceAtLeast(1).toFloat()
                        val maxH = (decor.height - v.height).coerceAtLeast(1).toFloat()
                        val nx = (startX + dx).coerceIn(0f, maxW)
                        val ny = (startY + dy).coerceIn(0f, maxH)
                        v.x = nx
                        v.y = ny
                        savedXFraction = nx / maxW
                        savedYFraction = ny / maxH
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        val heldMs = System.currentTimeMillis() - downTime
                        if (heldMs >= 550L) {
                            NativeSpeedBridge.setSpeed(1.0)
                            pill.text = formatPillText(1.0)
                        } else {
                            isExpanded = true
                            pill.visibility = View.GONE
                            panel.visibility = View.VISIBLE
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun weightedMarginParams(context: Context): LinearLayout.LayoutParams {
        val m = dp(context, 3f)
        return LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(m, 0, m, 0)
        }
    }

    private fun sliderProgressToSpeed(progress: Int): Double {
        val minVal = 0.1
        val maxVal = 25.0
        val ratio = progress / 100.0
        val raw = minVal * (maxVal / minVal).pow(ratio)
        return when {
            raw < 1.0 -> (raw * 20.0).roundToInt() / 20.0
            raw < 5.0 -> (raw * 10.0).roundToInt() / 10.0
            else -> (raw * 2.0).roundToInt() / 2.0
        }
    }

    private fun speedToSliderProgress(speed: Double): Int {
        if (speed <= 0.1) return 0
        if (speed >= 25.0) return 100
        val minVal = 0.1
        val maxVal = 25.0
        val ratio = ln(speed / minVal) / ln(maxVal / minVal)
        return (ratio * 100.0).roundToInt().coerceIn(0, 100)
    }

    private fun formatPillText(speed: Double): String {
        return if (speed == 0.0) "⏸ 0x"
        else String.format(Locale.US, "⚡ %.2gx", speed)
    }

    private fun formatSpeedBig(speed: Double): String {
        return if (speed == 0.0) "PAUSED (0x)"
        else String.format(Locale.US, "%.2fx", speed)
    }

    private fun dp(context: Context, value: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.resources.displayMetrics
        ).roundToInt()
    }
}
