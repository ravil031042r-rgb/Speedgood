package com.speedgod.module

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.SystemClock
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.concurrent.atomic.AtomicBoolean

class MainHook : IXposedHookZygoteInit, IXposedHookLoadPackage {

    private class JavaClockSlot {
        var initialized = false
        var realBase = 0L
        var virtBase = 0L
        var lastSpeed = 1.0
    }

    companion object {
        @Volatile
        private var modulePath: String? = null
        private val hooksInstalled = AtomicBoolean(false)
        private val lifecycleRegistered = AtomicBoolean(false)

        private val javaLock = Any()
        private val javaSlots = Array(3) { JavaClockSlot() }
    }

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam) {
        modulePath = startupParam.modulePath
        XposedBridge.log("[SpeedGod] initZygote modulePath=$modulePath")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val pkg = lpparam.packageName ?: return
        if (pkg == "com.speedgod.module" || pkg == "android" || pkg == "com.android.systemui") {
            return
        }

        if (!hooksInstalled.compareAndSet(false, true)) {
            return
        }

        if (modulePath.isNullOrBlank()) {
            modulePath = resolveModulePathFromClassLoader()
        }

        XposedBridge.log("[SpeedGod] Attached to package: $pkg")

        // 1. Hook Application.onCreate to init native engine + lifecycle callbacks early
        try {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "onCreate",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val app = param.thisObject as? Application ?: return
                        NativeSpeedBridge.ensureInitialized(modulePath, app)
                        if (lifecycleRegistered.compareAndSet(false, true)) {
                            registerLifecycle(app)
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[SpeedGod] Application.onCreate hook error: ${t.message}")
        }

        // 2. Safety-net Activity.onResume hook (works for UnityPlayerActivity / NativeActivity too)
        try {
            XposedHelpers.findAndHookMethod(
                Activity::class.java,
                "onResume",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val activity = param.thisObject as? Activity ?: return
                        NativeSpeedBridge.ensureInitialized(modulePath, activity.applicationContext)
                        OverlayManager.attachToActivity(activity)
                    }
                }
            )
            XposedHelpers.findAndHookMethod(
                Activity::class.java,
                "onPause",
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val activity = param.thisObject as? Activity ?: return
                        OverlayManager.detachFromActivity(activity)
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[SpeedGod] Activity lifecycle hook error: ${t.message}")
        }

        // 3. Java fallback time hooks (inert when Native ShadowHook is active!)
        installJavaFallbackHooks()
    }

    private fun registerLifecycle(app: Application) {
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityResumed(activity: Activity) {
                OverlayManager.attachToActivity(activity)
            }
            override fun onActivityPaused(activity: Activity) {
                OverlayManager.detachFromActivity(activity)
            }
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {
                OverlayManager.detachFromActivity(activity)
            }
        })
    }

    private fun installJavaFallbackHooks() {
        try {
            XposedHelpers.findAndHookMethod(
                SystemClock::class.java,
                "uptimeMillis",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (NativeSpeedBridge.isNativeLoaded) return
                        val raw = (param.result as? Long) ?: return
                        param.result = computeJavaTime(raw, 0, NativeSpeedBridge.currentSpeed)
                    }
                }
            )
            XposedHelpers.findAndHookMethod(
                SystemClock::class.java,
                "elapsedRealtime",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (NativeSpeedBridge.isNativeLoaded) return
                        val raw = (param.result as? Long) ?: return
                        param.result = computeJavaTime(raw, 1, NativeSpeedBridge.currentSpeed)
                    }
                }
            )
            XposedHelpers.findAndHookMethod(
                System::class.java,
                "currentTimeMillis",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        if (NativeSpeedBridge.isNativeLoaded) return
                        val raw = (param.result as? Long) ?: return
                        val effSpeed = if (NativeSpeedBridge.hookRealtime) NativeSpeedBridge.currentSpeed else 1.0
                        param.result = computeJavaTime(raw, 2, effSpeed)
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("[SpeedGod] Java fallback hook skipped: ${t.message}")
        }
    }

    private fun computeJavaTime(raw: Long, slotIdx: Int, targetSpeed: Double): Long {
        synchronized(javaLock) {
            val s = javaSlots[slotIdx]
            if (!s.initialized) {
                s.realBase = raw
                s.virtBase = raw
                s.lastSpeed = targetSpeed
                s.initialized = true
                return raw
            }
            val delta = (raw - s.realBase).coerceAtLeast(0L)
            val virt = s.virtBase + (delta * s.lastSpeed).toLong()
            if (targetSpeed != s.lastSpeed) {
                s.realBase = raw
                s.virtBase = virt
                s.lastSpeed = targetSpeed
            }
            return virt
        }
    }

    private fun resolveModulePathFromClassLoader(): String? {
        return try {
            val clStr = MainHook::class.java.classLoader?.toString() ?: return null
            val regex = Regex("(/[^,\\[\\]\"'\\s]+\\.apk)")
            regex.find(clStr)?.groupValues?.getOrNull(1)
        } catch (_: Throwable) {
            null
        }
    }
}
