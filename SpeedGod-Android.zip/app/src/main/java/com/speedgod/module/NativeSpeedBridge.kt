package com.speedgod.module

import android.animation.ValueAnimator
import android.content.Context
import android.os.Build
import android.os.Process
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.util.zip.ZipFile

object NativeSpeedBridge {

    @Volatile
    var isNativeLoaded: Boolean = false
        private set

    @Volatile
    var currentSpeed: Double = 1.0
        private set

    @Volatile
    var hookRealtime: Boolean = true
        private set

    @Volatile
    var hookSleep: Boolean = false
        private set

    @Volatile
    var statusText: String = "Java Fallback"
        private set

    @Volatile
    private var initAttempted: Boolean = false

    @JvmStatic
    external fun nativeInit(): Int

    @JvmStatic
    external fun nativeSetSpeed(speed: Double)

    @JvmStatic
    external fun nativeSetHookRealtime(enabled: Boolean)

    @JvmStatic
    external fun nativeSetHookSleep(enabled: Boolean)

    @JvmStatic
    external fun nativeGetStatus(): String

    @Synchronized
    fun ensureInitialized(modulePath: String?, context: Context?) {
        if (initAttempted) return
        initAttempted = true

        val abi = detectProcessAbi()
        val loaded = tryLoadFromApkDirect(modulePath, abi)
            || tryLoadSystemLibrary()
            || tryLoadByExtracting(modulePath, abi, context)

        if (loaded) {
            try {
                val count = nativeInit()
                if (count > 0) {
                    isNativeLoaded = true
                    statusText = nativeGetStatus()
                    XposedBridge.log("[SpeedGod] Native engine active: $statusText (ABI=$abi)")
                    return
                }
            } catch (t: Throwable) {
                XposedBridge.log("[SpeedGod] nativeInit failed: ${t.message}")
            }
        }

        isNativeLoaded = false
        statusText = "Java Fallback"
        XposedBridge.log("[SpeedGod] Native load unavailable, running in Java Fallback mode (ABI=$abi)")
    }

    fun setSpeed(speed: Double) {
        val clamped = speed.coerceIn(0.0, 100.0)
        currentSpeed = clamped
        if (isNativeLoaded) {
            try {
                nativeSetSpeed(clamped)
            } catch (t: Throwable) {
                XposedBridge.log("[SpeedGod] nativeSetSpeed error: ${t.message}")
            }
        }
        applyAnimatorDurationScale(clamped)
    }

    fun setHookRealtime(enabled: Boolean) {
        hookRealtime = enabled
        if (isNativeLoaded) {
            try {
                nativeSetHookRealtime(enabled)
            } catch (_: Throwable) {}
        }
    }

    fun setHookSleep(enabled: Boolean) {
        hookSleep = enabled
        if (isNativeLoaded) {
            try {
                nativeSetHookSleep(enabled)
            } catch (_: Throwable) {}
        }
    }

    private fun applyAnimatorDurationScale(speed: Double) {
        try {
            val scale = if (speed <= 0.0) 0f else (1.0 / speed).toFloat().coerceIn(0.01f, 20f)
            val method = ValueAnimator::class.java.getMethod("setDurationScale", Float::class.javaPrimitiveType)
            method.invoke(null, scale)
        } catch (_: Throwable) {
            // Hidden API may be restricted on some ROMs; native clock hooks handle animations anyway
        }
    }

    private fun detectProcessAbi(): String {
        val is64 = Process.is64Bit()
        val list = if (is64) Build.SUPPORTED_64_BIT_ABIS else Build.SUPPORTED_32_BIT_ABIS
        return list.firstOrNull { it == "arm64-v8a" || it == "armeabi-v7a" }
            ?: if (is64) "arm64-v8a" else "armeabi-v7a"
    }

    @Suppress("UnsafeDynamicallyLoadedCode")
    private fun tryLoadFromApkDirect(modulePath: String?, abi: String): Boolean {
        if (modulePath.isNullOrBlank()) return false
        return try {
            // Load dependency libshadowhook.so FIRST, then libspeedhack.so directly from APK zip
            System.load("$modulePath!/lib/$abi/libshadowhook.so")
            System.load("$modulePath!/lib/$abi/libspeedhack.so")
            true
        } catch (t: Throwable) {
            XposedBridge.log("[SpeedGod] Direct APK .so load skipped: ${t.message}")
            false
        }
    }

    private fun tryLoadSystemLibrary(): Boolean {
        return try {
            System.loadLibrary("shadowhook")
            System.loadLibrary("speedhack")
            true
        } catch (_: Throwable) {
            false
        }
    }

    @Suppress("UnsafeDynamicallyLoadedCode")
    private fun tryLoadByExtracting(modulePath: String?, abi: String, context: Context?): Boolean {
        if (modulePath.isNullOrBlank() || context == null) return false
        return try {
            val outDir = File(context.codeCacheDir, "speedgod_libs/$abi")
            if (!outDir.exists()) outDir.mkdirs()
            val libNames = listOf("libshadowhook.so", "libspeedhack.so")
            val extractedFiles = mutableListOf<File>()

            ZipFile(modulePath).use { zip ->
                for (name in libNames) {
                    val entry = zip.getEntry("lib/$abi/$name") ?: return false
                    val outFile = File(outDir, name)
                    if (!outFile.exists() || outFile.length() != entry.size) {
                        zip.getInputStream(entry).use { input ->
                            outFile.outputStream().use { output ->
                                input.copyTo(output)
                            }
                        }
                        outFile.setReadable(true, false)
                        outFile.setExecutable(true, false)
                    }
                    extractedFiles.add(outFile)
                }
            }

            for (file in extractedFiles) {
                System.load(file.absolutePath)
            }
            true
        } catch (t: Throwable) {
            XposedBridge.log("[SpeedGod] Extracted .so load failed: ${t.message}")
            false
        }
    }
}
