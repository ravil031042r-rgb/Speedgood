#include <jni.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdint.h>
#include <math.h>
#include <atomic>
#include <string>
#include <android/log.h>
#include <shadowhook.h>

#define LOG_TAG "SpeedGodNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr int MAX_CLOCK_ID = 16;

// Lock-free seqlock anchor for each clockid_t
struct ClockAnchor {
    std::atomic<uint64_t> seq{0};
    bool initialized{false};
    int64_t real_base_ns{0};
    int64_t virt_base_ns{0};
    double speed{1.0};
};

// Lock-free seqlock anchor for gettimeofday
struct TodAnchor {
    std::atomic<uint64_t> seq{0};
    bool initialized{false};
    int64_t real_base_us{0};
    int64_t virt_base_us{0};
    double speed{1.0};
};

ClockAnchor g_clocks[MAX_CLOCK_ID];
TodAnchor g_tod;

std::atomic_flag g_write_lock = ATOMIC_FLAG_INIT;
std::atomic<bool> g_initialized{false};
std::atomic<double> g_speed{1.0};
std::atomic<bool> g_hook_realtime{true};
std::atomic<bool> g_hook_sleep{false};

std::string g_status_msg = "Not initialized";

using fn_clock_gettime_t = int (*)(clockid_t, struct timespec*);
using fn_gettimeofday_t = int (*)(struct timeval*, struct timezone*);
using fn_nanosleep_t = int (*)(const struct timespec*, struct timespec*);
using fn_usleep_t = int (*)(useconds_t);

fn_clock_gettime_t orig_clock_gettime = nullptr;
fn_gettimeofday_t orig_gettimeofday = nullptr;
fn_nanosleep_t orig_nanosleep = nullptr;
fn_usleep_t orig_usleep = nullptr;

inline void acquire_write_lock() {
    while (g_write_lock.test_and_set(std::memory_order_acquire)) {
        // Brief spin
    }
}

inline void release_write_lock() {
    g_write_lock.clear(std::memory_order_release);
}

inline int64_t timespec_to_ns(const struct timespec& ts) {
    return static_cast<int64_t>(ts.tv_sec) * 1000000000LL + static_cast<int64_t>(ts.tv_nsec);
}

inline void ns_to_timespec(int64_t ns, struct timespec* ts) {
    if (ns < 0) ns = 0;
    ts->tv_sec = static_cast<time_t>(ns / 1000000000LL);
    ts->tv_nsec = static_cast<long>(ns % 1000000000LL);
}

inline int64_t timeval_to_us(const struct timeval& tv) {
    return static_cast<int64_t>(tv.tv_sec) * 1000000LL + static_cast<int64_t>(tv.tv_usec);
}

inline void us_to_timeval(int64_t us, struct timeval* tv) {
    if (us < 0) us = 0;
    tv->tv_sec = static_cast<time_t>(us / 1000000LL);
    tv->tv_usec = static_cast<suseconds_t>(us % 1000000LL);
}

inline bool is_monotonic_clock(clockid_t clk_id) {
    return clk_id == CLOCK_MONOTONIC
        || clk_id == CLOCK_MONOTONIC_RAW
        || clk_id == CLOCK_MONOTONIC_COARSE
        || clk_id == CLOCK_BOOTTIME;
}

inline bool is_realtime_clock(clockid_t clk_id) {
    return clk_id == CLOCK_REALTIME
        || clk_id == CLOCK_REALTIME_COARSE;
}

inline bool should_accelerate_clock(clockid_t clk_id) {
    if (clk_id < 0 || clk_id >= MAX_CLOCK_ID) return false;
    if (is_monotonic_clock(clk_id)) return true;
    if (is_realtime_clock(clk_id)) return g_hook_realtime.load(std::memory_order_relaxed);
    return false;
}

void init_single_clock_locked(clockid_t clk_id, double speed) {
    if (!orig_clock_gettime || clk_id < 0 || clk_id >= MAX_CLOCK_ID) return;
    struct timespec ts{};
    if (orig_clock_gettime(clk_id, &ts) != 0) return;
    int64_t now_ns = timespec_to_ns(ts);

    ClockAnchor& c = g_clocks[clk_id];
    uint64_t s = c.seq.load(std::memory_order_relaxed);
    c.seq.store(s + 1, std::memory_order_release);
    c.real_base_ns = now_ns;
    c.virt_base_ns = now_ns;
    c.speed = speed;
    c.initialized = true;
    c.seq.store(s + 2, std::memory_order_release);
}

void init_tod_locked(double speed) {
    if (!orig_gettimeofday) return;
    struct timeval tv{};
    if (orig_gettimeofday(&tv, nullptr) != 0) return;
    int64_t now_us = timeval_to_us(tv);

    uint64_t s = g_tod.seq.load(std::memory_order_relaxed);
    g_tod.seq.store(s + 1, std::memory_order_release);
    g_tod.real_base_us = now_us;
    g_tod.virt_base_us = now_us;
    g_tod.speed = speed;
    g_tod.initialized = true;
    g_tod.seq.store(s + 2, std::memory_order_release);
}

void update_all_anchors(double new_speed, bool new_hook_realtime) {
    acquire_write_lock();

    const clockid_t managed_clocks[] = {
        CLOCK_REALTIME,
        CLOCK_MONOTONIC,
        CLOCK_MONOTONIC_RAW,
        CLOCK_REALTIME_COARSE,
        CLOCK_MONOTONIC_COARSE,
        CLOCK_BOOTTIME
    };

    for (clockid_t clk_id : managed_clocks) {
        if (clk_id < 0 || clk_id >= MAX_CLOCK_ID) continue;
        ClockAnchor& c = g_clocks[clk_id];
        if (!orig_clock_gettime) continue;

        struct timespec ts{};
        if (orig_clock_gettime(clk_id, &ts) != 0) continue;
        int64_t r_now = timespec_to_ns(ts);

        double eff_speed = is_realtime_clock(clk_id)
            ? (new_hook_realtime ? new_speed : 1.0)
            : new_speed;

        int64_t v_now = r_now;
        if (c.initialized) {
            int64_t delta = r_now - c.real_base_ns;
            if (delta < 0) delta = 0;
            v_now = c.virt_base_ns + static_cast<int64_t>(static_cast<double>(delta) * c.speed);
        }

        uint64_t s = c.seq.load(std::memory_order_relaxed);
        c.seq.store(s + 1, std::memory_order_release);
        c.real_base_ns = r_now;
        c.virt_base_ns = v_now;
        c.speed = eff_speed;
        c.initialized = true;
        c.seq.store(s + 2, std::memory_order_release);
    }

    if (orig_gettimeofday) {
        struct timeval tv{};
        if (orig_gettimeofday(&tv, nullptr) == 0) {
            int64_t r_now = timeval_to_us(tv);
            double eff_speed = new_hook_realtime ? new_speed : 1.0;

            int64_t v_now = r_now;
            if (g_tod.initialized) {
                int64_t delta = r_now - g_tod.real_base_us;
                if (delta < 0) delta = 0;
                v_now = g_tod.virt_base_us + static_cast<int64_t>(static_cast<double>(delta) * g_tod.speed);
            }

            uint64_t s = g_tod.seq.load(std::memory_order_relaxed);
            g_tod.seq.store(s + 1, std::memory_order_release);
            g_tod.real_base_us = r_now;
            g_tod.virt_base_us = v_now;
            g_tod.speed = eff_speed;
            g_tod.initialized = true;
            g_tod.seq.store(s + 2, std::memory_order_release);
        }
    }

    g_speed.store(new_speed, std::memory_order_release);
    g_hook_realtime.store(new_hook_realtime, std::memory_order_release);

    release_write_lock();
}

// ==================== HOOK PROXIES ====================

int my_clock_gettime(clockid_t clk_id, struct timespec* ts) {
    int ret = orig_clock_gettime(clk_id, ts);
    if (ret != 0 || ts == nullptr) {
        return ret;
    }

    if (!should_accelerate_clock(clk_id)) {
        return ret;
    }

    ClockAnchor& c = g_clocks[clk_id];
    int64_t r_now = timespec_to_ns(*ts);

    int64_t real_base = 0;
    int64_t virt_base = 0;
    double speed = 1.0;
    bool init = false;

    for (int tries = 0; tries < 8; ++tries) {
        uint64_t s1 = c.seq.load(std::memory_order_acquire);
        if (s1 & 1ULL) continue;
        init = c.initialized;
        real_base = c.real_base_ns;
        virt_base = c.virt_base_ns;
        speed = c.speed;
        uint64_t s2 = c.seq.load(std::memory_order_acquire);
        if (s1 == s2) break;
    }

    if (!init) {
        return ret;
    }

    int64_t delta = r_now - real_base;
    if (delta < 0) delta = 0;
    int64_t v_now = virt_base + static_cast<int64_t>(static_cast<double>(delta) * speed);
    ns_to_timespec(v_now, ts);
    return ret;
}

int my_gettimeofday(struct timeval* tv, struct timezone* tz) {
    int ret = orig_gettimeofday(tv, tz);
    if (ret != 0 || tv == nullptr) {
        return ret;
    }

    if (!g_hook_realtime.load(std::memory_order_relaxed)) {
        return ret;
    }

    int64_t r_now = timeval_to_us(*tv);

    int64_t real_base = 0;
    int64_t virt_base = 0;
    double speed = 1.0;
    bool init = false;

    for (int tries = 0; tries < 8; ++tries) {
        uint64_t s1 = g_tod.seq.load(std::memory_order_acquire);
        if (s1 & 1ULL) continue;
        init = g_tod.initialized;
        real_base = g_tod.real_base_us;
        virt_base = g_tod.virt_base_us;
        speed = g_tod.speed;
        uint64_t s2 = g_tod.seq.load(std::memory_order_acquire);
        if (s1 == s2) break;
    }

    if (!init) {
        return ret;
    }

    int64_t delta = r_now - real_base;
    if (delta < 0) delta = 0;
    int64_t v_now = virt_base + static_cast<int64_t>(static_cast<double>(delta) * speed);
    us_to_timeval(v_now, tv);
    return ret;
}

int my_nanosleep(const struct timespec* req, struct timespec* rem) {
    if (!req || !g_hook_sleep.load(std::memory_order_relaxed)) {
        return orig_nanosleep(req, rem);
    }

    double spd = g_speed.load(std::memory_order_relaxed);
    if (spd <= 0.05 || fabs(spd - 1.0) < 0.01) {
        return orig_nanosleep(req, rem);
    }

    int64_t req_ns = timespec_to_ns(*req);
    if (req_ns <= 0) {
        return orig_nanosleep(req, rem);
    }

    int64_t scaled_ns = static_cast<int64_t>(static_cast<double>(req_ns) / spd);
    if (spd > 1.0 && scaled_ns < 100000LL) {
        scaled_ns = 100000LL;
    } else if (spd < 1.0 && scaled_ns > 50000000LL && req_ns < 50000000LL) {
        scaled_ns = 50000000LL;
    }

    struct timespec mod_req{};
    ns_to_timespec(scaled_ns, &mod_req);
    return orig_nanosleep(&mod_req, rem);
}

int my_usleep(useconds_t usec) {
    if (!g_hook_sleep.load(std::memory_order_relaxed) || usec == 0) {
        return orig_usleep(usec);
    }

    double spd = g_speed.load(std::memory_order_relaxed);
    if (spd <= 0.05 || fabs(spd - 1.0) < 0.01) {
        return orig_usleep(usec);
    }

    double scaled = static_cast<double>(usec) / spd;
    if (spd > 1.0 && scaled < 100.0) {
        scaled = 100.0;
    } else if (spd < 1.0 && scaled > 50000.0 && usec < 50000) {
        scaled = 50000.0;
    }
    return orig_usleep(static_cast<useconds_t>(scaled));
}

} // namespace

extern "C" {

JNIEXPORT jint JNICALL
Java_com_speedgod_module_NativeSpeedBridge_nativeInit(JNIEnv* /*env*/, jclass /*clazz*/) {
    if (g_initialized.load(std::memory_order_acquire)) {
        return 0;
    }

    int init_res = shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false);
    if (init_res != 0) {
        int err = shadowhook_get_errno();
        g_status_msg = std::string("ShadowHook init error: ") + shadowhook_to_errmsg(err);
        LOGE("%s", g_status_msg.c_str());
        return -1;
    }

    int hooked_count = 0;

    void* stub_cg = shadowhook_hook_sym_name(
        "libc.so", "clock_gettime",
        reinterpret_cast<void*>(my_clock_gettime),
        reinterpret_cast<void**>(&orig_clock_gettime)
    );
    if (stub_cg != nullptr) {
        hooked_count++;
    } else {
        LOGE("Failed to hook clock_gettime: %s", shadowhook_to_errmsg(shadowhook_get_errno()));
    }

    void* stub_tod = shadowhook_hook_sym_name(
        "libc.so", "gettimeofday",
        reinterpret_cast<void*>(my_gettimeofday),
        reinterpret_cast<void**>(&orig_gettimeofday)
    );
    if (stub_tod != nullptr) {
        hooked_count++;
    } else {
        LOGE("Failed to hook gettimeofday: %s", shadowhook_to_errmsg(shadowhook_get_errno()));
    }

    void* stub_ns = shadowhook_hook_sym_name(
        "libc.so", "nanosleep",
        reinterpret_cast<void*>(my_nanosleep),
        reinterpret_cast<void**>(&orig_nanosleep)
    );
    if (stub_ns != nullptr) {
        hooked_count++;
    }

    void* stub_us = shadowhook_hook_sym_name(
        "libc.so", "usleep",
        reinterpret_cast<void*>(my_usleep),
        reinterpret_cast<void**>(&orig_usleep)
    );
    if (stub_us != nullptr) {
        hooked_count++;
    }

    if (hooked_count == 0) {
        g_status_msg = "No libc hooks installed";
        return -2;
    }

    acquire_write_lock();
    init_single_clock_locked(CLOCK_REALTIME, 1.0);
    init_single_clock_locked(CLOCK_MONOTONIC, 1.0);
    init_single_clock_locked(CLOCK_MONOTONIC_RAW, 1.0);
    init_single_clock_locked(CLOCK_REALTIME_COARSE, 1.0);
    init_single_clock_locked(CLOCK_MONOTONIC_COARSE, 1.0);
    init_single_clock_locked(CLOCK_BOOTTIME, 1.0);
    init_tod_locked(1.0);
    release_write_lock();

    g_initialized.store(true, std::memory_order_release);
    g_status_msg = "Native OK (" + std::to_string(hooked_count) + " hooks)";
    LOGI("%s", g_status_msg.c_str());
    return hooked_count;
}

JNIEXPORT void JNICALL
Java_com_speedgod_module_NativeSpeedBridge_nativeSetSpeed(JNIEnv* /*env*/, jclass /*clazz*/, jdouble speed) {
    if (!g_initialized.load(std::memory_order_acquire)) return;
    double clamped = speed;
    if (clamped < 0.0) clamped = 0.0;
    if (clamped > 100.0) clamped = 100.0;
    update_all_anchors(clamped, g_hook_realtime.load(std::memory_order_relaxed));
}

JNIEXPORT void JNICALL
Java_com_speedgod_module_NativeSpeedBridge_nativeSetHookRealtime(JNIEnv* /*env*/, jclass /*clazz*/, jboolean enabled) {
    if (!g_initialized.load(std::memory_order_acquire)) return;
    update_all_anchors(g_speed.load(std::memory_order_relaxed), enabled == JNI_TRUE);
}

JNIEXPORT void JNICALL
Java_com_speedgod_module_NativeSpeedBridge_nativeSetHookSleep(JNIEnv* /*env*/, jclass /*clazz*/, jboolean enabled) {
    g_hook_sleep.store(enabled == JNI_TRUE, std::memory_order_release);
}

JNIEXPORT jstring JNICALL
Java_com_speedgod_module_NativeSpeedBridge_nativeGetStatus(JNIEnv* env, jclass /*clazz*/) {
    return env->NewStringUTF(g_status_msg.c_str());
}

} // extern "C"
