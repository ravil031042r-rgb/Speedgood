cmake_minimum_required(VERSION 3.22.1)
project(speedhack LANGUAGES CXX)

find_package(shadowhook REQUIRED CONFIG)

add_library(speedhack SHARED speedhack.cpp)

target_link_libraries(speedhack
    shadowhook::shadowhook
    log
)

# Android 15/16 16KB page size alignment compatibility
target_link_options(speedhack PRIVATE
    "-Wl,-z,max-page-size=16384"
)
